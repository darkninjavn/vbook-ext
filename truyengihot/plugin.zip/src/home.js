function execute() {
    return Response.success([
        { title: "Cập Nhật", input: "", script: "gen.js" },
        { title: "18+", input: "18", script: "source.js" },
        { title: "Harem", input: "harem", script: "source.js" },
    ]);
}